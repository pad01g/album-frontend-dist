import{W as n}from"./index-B9bkrNbk.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
