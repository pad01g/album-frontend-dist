import{W as n}from"./index-C9X2EgLH.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
