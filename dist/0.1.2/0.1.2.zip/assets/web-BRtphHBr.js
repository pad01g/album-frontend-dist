import{W as n}from"./index-jWVmy20J.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
