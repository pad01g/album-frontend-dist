import{W as n}from"./index-n6wAOLf-.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
